<?php $__env->startSection('title', 'Blog | Home'); ?>
<?php $__env->startSection('content'); ?>

        <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('images/home-bg.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="site-heading">
                        <h1>Laravel Blog</h1>
                        <hr class="small">
                        <span class="subheading">Subheading</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

     <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    <?php echo $__env->yieldContent('title'); ?>
                    <small>#</small>
                </h1>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <h2>
        <a href="<?php echo e(route('home.post', $post->slug)); ?>"><?php echo e($post->title); ?></a>
    </h2>
    <p class="lead">
        by <a href="index.php"><?php echo e($post->user->name); ?></a>
    </p>
    <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at); ?></p>
    <hr>
    <img height="200" class="img-responsive" src="<?php echo e(url($post->photo->path)); ?>" alt="">
    <hr>
    <p><?php echo e(strip_tags(str_limit($post->body, 300))); ?></p>
    <a class="btn btn-primary" href="<?php echo e(route('home.post', $post->slug)); ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

    <hr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <div class="row">
      <div class="col-sm-6 col-sm-offset-7">
          <?php echo e($posts->render()); ?>

      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>