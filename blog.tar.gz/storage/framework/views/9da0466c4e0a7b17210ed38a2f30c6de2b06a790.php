<?php $__env->startSection('Admin shop', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  <div class="panel panel-info">
      <div class="panel-heading">
          <div class="panel-title">All products</div>
      </div>
      <div class="panel-body" >

              <div class="row">
                  <div class="col-md-6">
                      <a href="<?php echo e(url("/admin/shop/new")); ?>"><button class="btn btn-success">New Product</button></a>
                  </div>
              </div>
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>id</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>File</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Edit</th>
                            <th>Delete</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->price); ?>$</td>
                                <td><?php echo e($product->file['filename']); ?></td>
                                <td><?php echo e($product->category ? $product->category->name : "Undefined"); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td><a href="<?php echo e(url("shop/edit", $product->id)); ?>"><button class="btn btn-primary">Edit</button></a> </td>
                                <td><a href="/shop/product/destroy/<?php echo e($product->id); ?>"><button class="btn btn-danger">Delete</button></a> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                          </tbody>
                      </table>
          </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>