<?php $__env->startSection('title', 'Home page'); ?>

<!-- Page Content -->
<?php $__env->startSection('styles'); ?>
  <link href="css/shop-homepage.css" rel="stylesheet">
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-md-12">
      <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
              <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-generic" data-slide-to="1"></li>
              <li data-target="#carousel-example-generic" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
              <div class="item active">
                  <h3><span>Adverts text placeholder 1</span></h3>
                  <img class="slide-image" src="<?php echo e(url("photos/shop1-800x300.jpg")); ?>" alt="">

              </div>
              <div class="item">
                  <h3><span>Adverts text placeholder 2</span></h3>
                  <img class="slide-image" src="<?php echo e(url("photos/shop2-800x300.jpg")); ?>" alt="">
              </div>
              <div class="item">
                  <h3><span>Adverts text placeholder 3</span></h3>
                  <img class="slide-image" src="<?php echo e(url("photos/shop3-800x300.jpg")); ?>" alt="">
              </div>
          </div>
          <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
          </a>
          <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
          </a>
      </div>
  </div>

</div>

<div class="row">
  <div class="col-md-12">

      <div id="sort-btn" class="dropdown pull-right">
      <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
        Sort by
        <span class="caret"></span>
      </button>
      <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
        <li><a href="<?php echo e(url('/newest')); ?>">Newest</a></li>
        <li><a href="<?php echo e(url('/oldest')); ?>">Oldest</a></li>
        <li><a href="<?php echo e(url('/price_asc')); ?>">Price: low to high</a></li>
        <li><a href="<?php echo e(url('/price_desc')); ?>">Price: high to low</a></li>
      </ul>
    </div>
  </div>
</div>

<div class="row">

  <?php if($products): ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <div class="col-sm-4 col-lg-4 col-md-4">

                      <div class="thumbnail">
                        <a href="<?php echo e(url('item', $product->id)); ?>">
                         <div id="thumbnail" >
                          <img class="rounded img-responsive" src="<?php echo e(url("images",$product->imageurl)); ?>" alt="">
                         </div>

                          <div class="caption">
                              <h4 class="pull-right">$<?php echo e($product->price); ?></h4>
                              <br>
                              <h4><a href="#"><?php echo e($product->name); ?></a>
                              </h4>
                              <p><?php echo e(strip_tags(str_limit($product->description, 150))); ?></p>
                          </div>
                          <div class="ratings">
                            <?php if($product->score() > 0): ?>
                              <p class="pull-right"><?php echo e(count($product->reviews) ==1 ? count($product->reviews). " review": count($product->reviews). " reviews"); ?></p>
                              <p>
                                <?php for($i=0; $i < $product->score(); $i++): ?>
                                  <span class="glyphicon glyphicon-star"></span>
                                <?php endfor; ?>
                                  <?php echo e($product->score()); ?>/5 stars
                              </p>
                            <?php else: ?>
                              <p>No rating yet</p>
                            <?php endif; ?>
                          </div>
                          <div class="row">
                              <div class="col-md-6">
                                <?php echo Form::open(['method'=>'GET', 'action'=>['CartController@addItem',$product->id ]]); ?>

                                    <?php echo Form::button('<span class="fa fa-shopping-cart"> Add to cart</span>', ['id'=>'', 'class'=>'btn btn-success btn-product', 'type'=>'submit']); ?>

                                <?php echo Form::close(); ?>

                              </div>
                          </div>
                      </div>
                    </a>

                  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <?php endif; ?>

  <div class="row">
    <div class="col-sm-6 col-sm-offset-3">
        <?php echo e($products->render()); ?>

    </div>
  </div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>