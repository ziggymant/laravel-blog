<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('styles'); ?>
  <link href="<?php echo e(url("css/starrating.css")); ?>" rel="stylesheet">
  <link href="css/shop-homepage.css" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="">
                     <img class="img-responsive" src="<?php echo e(url('images', $product->imageurl)); ?>" alt="">
                     <div class="caption-full">
                         <h4 class="pull-right">$<?php echo e($product->price); ?></h4>
                         <h4><a href="#"><?php echo e($product->name); ?></a>
                         </h4>
                         <p><?php echo $product->description; ?></p>
                         
                     </div>
                     <div class="ratings">
                         <p class="pull-right"><?php echo e(count($product->reviews)); ?> reviews</p>
                           <p>
                             <?php for($i=0; $i < $product->score(); $i++): ?>
                               <span class="glyphicon glyphicon-star"></span>
                             <?php endfor; ?>
                               <?php echo e($product->score()); ?>/5 stars
                           </p>
                     </div>
                 </div>

    <div class="well">

                   <div class="well">
                       <h4>Leave a review:</h4>
                       <?php echo Form::open(['method'=>'POST', 'action'=>'ProductPublicController@StoreReview']); ?>

                         <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                         <div class="form-group">
                           <?php echo Form::label('review', 'Review'); ?>

                           <?php echo Form::textarea('review', null, ['class'=>'form-control', 'rows'=>3]); ?>

                           
                           <input id="input-5" name="rating" class="rating-loading" data-show-clear="false" data-show-caption="true">

                         </div>

                         <div class="form-group">
                           <?php echo Form::submit('Post review', ['class'=>'btn btn-primary']); ?>

                         </div>

                       <?php echo Form::close(); ?>


                   </div>
                     <hr>
                    <?php if($product->reviews): ?>
                      <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                     <div class="row">
                         <div class="col-md-12">
                             <?php for($i=0; $i < $review->rating; $i++): ?>
                               <span class="glyphicon glyphicon-star"></span>
                             <?php endfor; ?>
                             (<?php echo e($review->rating); ?>/5)
                             <?php echo e($review->user->name); ?>

                             <span class="pull-right"><?php echo e($review->created_at->diffforhumans()); ?></span>
                             <p><?php echo e($review->review); ?></p>
                         </div>
                     </div>

                     <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  <?php elseif(emptyArray($reviews)): ?>

                    <h3 class="text-center">No reviews yet!</h3>
                   <?php endif; ?>

                 </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(url("js/starrating.js")); ?>">

</script>
<script>

$(document).on('ready', function(){
    $('#input-5').rating({clearCaption: 'No stars yet'});
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>