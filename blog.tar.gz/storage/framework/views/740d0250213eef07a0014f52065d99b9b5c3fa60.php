<?php $__env->startSection('styles'); ?>
  <link href="css/shop-homepage.css" rel="stylesheet">
  <link href="<?php echo e(url("css/starrating.css")); ?>" rel="stylesheet">
  <link href="<?php echo e(url("css/styles.css")); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- Project One -->
<div class="row">
    <?php if($products): ?>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row">
            <div class="col-md-7">
                <a href="#">
                   <div id="thumbnail">
                    <img height="170" class="img-responsive" src="<?php echo e(url('images', $product->imageurl)); ?>" alt="">
                   </div>
                </a>
            </div>
            <div class="col-md-5">
                <h3></h3>
                <h4><?php echo e($product->name); ?></h4>
                <h4 >$<?php echo e($product->price); ?></h4>
                
                <div class="ratings">
                    <p class="pull-right"><?php echo e(count($product->reviews) ==1 ? count($product->reviews). " review": count($product->reviews). " reviews"); ?></p>
                      <p>
                        <?php for($i=0; $i < $product->score(); $i++): ?>
                          <span class="glyphicon glyphicon-star"></span>
                        <?php endfor; ?>
                          <?php echo e($product->score()); ?>/5 stars
                      </p>
                </div>
                <p><?php echo e(strip_tags(str_limit($product->description, 500))); ?></p>
                <a class="btn btn-primary" href="<?php echo e(url('item', $product->id)); ?>">View Product <span class="glyphicon glyphicon-chevron-right"></span></a>
            </div>
        </div>
        <hr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php endif; ?>
        <!-- /.row -->

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(url("js/starrating.js")); ?>">

</script>
<script>

$(document).on('ready', function(){
    $('#input-5').rating({clearCaption: 'No stars yet'});
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>