<?php $__env->startSection('content'); ?>

<h1>Posts</h1>

<table class="table">
<thead>
  <tr>
    <th>Post id</th>
    <th>Photo</th>
    <th>User</th>
    <th>Category</th>
    <th>Title</th>
    <th>Body</th>
    <th>Comments</th>
    <th>Created at</th>
    <th>Updated at</th>
    <th>View post</th>
  </tr>
</thead>
<tbody>
<?php if($posts): ?>
  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <tr>
    <td><?php echo e($post->id); ?></td>
    <td><img height="50" src="<?php echo e($post->photo ? $post->photo->path : "images/default.jpg"); ?>" alt=""></td>
    <td><?php echo e($post->user->name); ?></td>
    <td><?php echo e($post->category ? $post->category->name : "uncategorized"); ?></td>
    <td><a href="/admin/posts/<?php echo e($post->id); ?>/edit"><?php echo e($post->title); ?></a></td>
    <td><?php echo e(str_limit($post->body, 10)); ?></td>
    <td><a href="<?php echo e(route('comments.show', $post->id)); ?>">View comments</a></td>
    <td><?php echo e($post->created_at->diffForHumans()); ?></td>
    <td><?php echo e($post->updated_at); ?></td>
    <td><a href="<?php echo e(route('home.post', $post->slug)); ?>">View post</a></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php endif; ?>
</tbody>
</table>

<div class="row">
  <div class="col-sm-6 col-sm-offset-5">
      <?php echo e($posts->render()); ?>

  </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>