<?php $__env->startSection('New Product', 'Page Title'); ?>

<?php $__env->startSection('styles'); ?>

<script src="<?php echo e(asset('/js/summernote.js')); ?>"></script>
<link href="<?php echo e(asset('css/summernote.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="panel panel-info">
        <div class="panel-heading">
            <div class="panel-title">New Product</div>
        </div>
        <div class="panel-body" >

              <?php echo Form::open(['method'=>'POST', 'action'=>'ProductController@add', 'files'=>true]); ?>


                    <!-- Text input-->
                    <div class="form-group">
                      <?php echo Form::label('name', 'Product name', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::text('name', null, ['placeholder'=>'Product name','class'=>'form-control input-md']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('description', 'Description', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::textarea('description', null, ['placeholder'=>'Description','id'=>'texarea', 'class'=>'form-control', 'id'=>'summernote']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('price', 'Price', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::text('price', null, ['placeholder'=>'Price','class'=>'form-control input-md']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                  		<?php echo Form::label('category_id', 'Category',  ['class'=>'col-md-3 control-label']); ?>

                      <div class="col-md-9">
                  		    <?php echo Form::select('category_id',$categories  , null, ['class'=>'form-control input-md']); ?>

                      </div>
                  	</div>

                    <div class="form-group">
                      <?php echo Form::label('image', 'Image', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::file('image', null, ['id'=>'imageurl','class'=>'form-control input-md']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('file', 'Product', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9 pull-right">
                          <?php echo Form::file('file', null, ['id'=>'imageurl','class'=>'form-control input-md']); ?>

                        </div>
                    </div>



                    <div class="form-group">
                        <div class="col-md-9">
                          <?php echo Form::submit('submit', ['id'=>'submit','class'=>'btn btn-primary']); ?>

                        </div>
                    </div>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
    $('#summernote').summernote({
      height: 300,                 // set editor height
      minHeight: null,             // set minimum height of editor
      maxHeight: null,             // set maximum height of editor
      focus: true                  // set focus to editable area after initializing summernote
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>