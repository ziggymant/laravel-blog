<?php $__env->startSection('styles'); ?>

<script src="<?php echo e(asset('/js/summernote.js')); ?>"></script>
<link href="<?php echo e(asset('css/summernote.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<h1>Create Post</h1>

<?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::open(['method'=>'POST', 'action'=>'AdminPostsController@store', 'files'=>true]); ?>


  <div class="form-group">
  <?php echo Form::label('title', 'Title'); ?>

  <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

  </div>
  <div class="form-group">
  <?php echo Form::label('category_id', 'Category'); ?>

  <?php echo Form::select('category_id', $categories , null, ['class'=>'form-control']); ?>

  </div>

  <div class="form-group">
  <?php echo Form::label('photo_id', 'Photo'); ?>

  <?php echo Form::file('photo_id', ['class'=>'form-control']); ?>

  </div>
  <div class="form-group">
  <?php echo Form::label('body', 'Post'); ?>

  <?php echo Form::textarea('body', null, ['class'=>'form-control', 'id' => 'summernote']); ?>

  </div>

  <div class="form-group">
<?php echo Form::submit('Create post', ['class'=>'btn btn-primary']); ?>

</div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
    $(document).ready(function() {
    $('#summernote').summernote({
        height: 300,
        onImageUpload: function(files, editor, welEditable) {
            sendFile(files[0], editor, welEditable);
        }
    });
    function sendFile(file, editor, welEditable) {
        data = new FormData();
        data.append("file", file);
        $.ajax({
            data: data,
            type: "POST",
            url: "http://project.dev/admin/post/img",
            cache: false,
            contentType: false,
            processData: false,
            success: function(url) {
                editor.insertImage(welEditable, url);
            }
        });
    }
});
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>