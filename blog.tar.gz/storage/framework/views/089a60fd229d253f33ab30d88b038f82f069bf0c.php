<nav id="shop-nav" class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Home</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div id="nav-links" class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul  class="nav navbar-nav">
                <li>
                    <a href="#">About</a>
                </li>
                <li>
                    <a href="#">Placehold</a>
                </li>
                <li>
                    <a href="<?php echo e(url('blog/posts')); ?>">Blog</a>
                </li>
              </ul>

              <ul class="nav navbar-nav navbar-right">
                <?php if(Auth::user()): ?>
                    <li><a href="<?php echo e(url('/shop/orders')); ?>">My Orders <span class="fa fa-briefcase"></span></a></li>
                    <li><a href="<?php echo e(url('shop/cart')); ?>">Cart <?php echo e(Auth::user()->cartItems() ? "(" .Auth::user()->cartItems(). ")" : ""); ?> <span class="fa fa-shopping-cart"></span></a></li>
                <?php endif; ?>

                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(url('/logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                            <?php if(Auth::user()->isAdmin()): ?>
                              <li>
                                  <a href="<?php echo e(url('/admin/index')); ?>">Admin page</a>
                              </li>
                            <?php endif; ?>
                            <?php if(Auth::user()): ?>
                              <li>
                                  <a href="<?php echo e(url('profile', Auth::id())); ?>">User profile</a>
                              </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
              </ul>

        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>
