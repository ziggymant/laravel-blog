<?php $__env->startSection('content'); ?>

<!-- First Blog Post -->
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <h2>
        <a href="<?php echo e(route('home.post', $post->slug)); ?>"><?php echo e($post->title); ?></a>
    </h2>
    <p class="lead">
        by <a href="index.php"><?php echo e($post->user->name); ?></a>
    </p>
    <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at); ?></p>
    <hr>
    <img height="300" class="img-responsive" src="<?php echo e($post->photo->path); ?>" alt="">
    <hr>
    <p><?php echo e(str_limit($post->body, 300)); ?></p>
    <a class="btn btn-primary" href="<?php echo e(route('home.post', $post->slug)); ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>