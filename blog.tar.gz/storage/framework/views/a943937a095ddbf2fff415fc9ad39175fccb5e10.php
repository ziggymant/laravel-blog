<?php $__env->startSection('styles'); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

  <h1>Upload media</h1>

  <?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo Form::open(['method'=>'POST', 'action'=>'AdminMediaConrtoller@store', 'class'=>'dropzone']); ?>



  <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>