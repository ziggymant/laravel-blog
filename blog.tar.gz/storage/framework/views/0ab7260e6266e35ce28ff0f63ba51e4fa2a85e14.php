<?php $__env->startSection('head'); ?>
  <?php echo Charts::assets(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row ">
      <div class="panel">
        <div class="panel-body col-md-5">
          <?php echo $chart2->render(); ?>

        </div>
        <div class="panel-body col-md-5">
          <?php echo $chart3->render(); ?>

        </div>
      </div>
    </div>

    <div class="row ">
      <div class="panel">
        <div class="panel-body col-md-5">
          <?php echo $chart4->render(); ?>

        </div>
        <div class="panel-body col-md-5">
          <?php echo $chart->render(); ?>

        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>