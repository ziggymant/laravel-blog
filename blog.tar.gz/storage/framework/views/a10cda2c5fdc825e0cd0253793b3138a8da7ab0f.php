<?php $__env->startSection('content'); ?>

<h1>Edit user</h1>

<div class="col-sm-3">

	<img height="150" src="<?php echo e($user->photo ? $user->photo->path : "/images/default.jpg"); ?>" class="img-resposnive img-rounded">

</div>

<div class="col-sm-9">

<?php if(count($errors)>0): ?>
	<div class="alert alert-danger">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	</div>
<?php endif; ?>

	<?php echo Form::model($user, ['method'=>'PATCH', 'action'=>['AdminUsersController@update', $user->id], 'files'=>true]); ?>


		<div class="form-group">
			<?php echo Form::label('name', 'Name'); ?>

			<?php echo Form::Text('name', null, ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('email', 'Email'); ?>

			<?php echo Form::email('email', null, ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('role_id', 'Role'); ?>

			<?php echo Form::select('role_id',$roles, null, ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('status', 'Status'); ?>

			<?php echo Form::select('is_active', array(1 =>'active', 0 =>'Inactive'), null, ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('password', 'Password'); ?>

			<?php echo Form::password('password', ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('photo_id', 'Photo'); ?>

			<?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::submit('Edit user', ['class'=>'btn btn-primary col-sm-3']); ?>

		</div>

	<?php echo Form::close(); ?>



	<?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminUsersController@destroy', $user->id]]); ?>


		<div class="form-group">
			<?php echo Form::submit('Delete user', ['class'=>'btn btn-danger col-sm-3']); ?>

		</div>

	<?php echo Form::close(); ?>


</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>