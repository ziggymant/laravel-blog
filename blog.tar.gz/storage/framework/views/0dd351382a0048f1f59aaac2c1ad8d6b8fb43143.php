<?php $__env->startSection('content'); ?>

     <!-- Page Content -->
    <div class="container">

        <div id="post" class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    <?php echo $__env->yieldContent('title'); ?>
                    <small>#</small>
                </h1>

  <!-- Blog Post -->

  <!-- Title -->
  <h1><?php echo e($post->title); ?></h1>

  <?php if(Session::has('message')): ?>
    <p class="text-success"><?php echo e(Session('message')); ?></p>
  <?php endif; ?>

  <!-- Author -->
  <p class="lead">
      by <a href="#"><?php echo e($post->user->name); ?></a>
  </p>

  <hr>

  <!-- Date/Time -->
  <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at); ?></p>

  <hr>

  <!-- Preview Image -->
  <img class="img-responsive" src="<?php echo e(url($post->photo->path)); ?>" alt="">

  <hr>

  <!-- Post Content -->
  <?php echo $post->body; ?>


  <hr>

  <!-- Blog Comments -->
<?php if(Auth::check()): ?>
  <!-- Comments Form -->
  <div class="well">
      <h4>Leave a Comment:</h4>


      <?php echo Form::open(['method'=>'POST', 'action'=>'PostCommentsController@store']); ?>


        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
        <div class="form-group">
          <?php echo Form::label('body', 'Comment'); ?>

          <?php echo Form::textarea('body', null, ['class'=>'form-control', 'rows'=>3]); ?>

        </div>

        <div class="form-group">
          <?php echo Form::submit('Post comment', ['class'=>'btn btn-primary']); ?>

        </div>

      <?php echo Form::close(); ?>



  </div>
<?php endif; ?>

  <hr>

  <!-- Posted Comments -->
<?php if(count($comments)>0): ?>
  <!-- Comment -->
  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="media">
      <a class="pull-left" href="#">
          <img height="64" class="media-object" src="<?php echo e($comment->authorPhoto($comment->author)); ?>" alt="">
      </a>
      <?php if(Auth::check()): ?>
      <button class="toggle-reply btn btn-primary pull-right">Reply</button>
      <?php endif; ?>
      <div class="media-body">
          <h4 class="media-heading"><?php echo e($comment->author); ?>

              <small><?php echo e($comment->created_at->diffForHumans()); ?></small>
          </h4>
          <?php echo e($comment->body); ?>


          <div class="comment-reply-container">
              <div class="comment-reply">
                  <?php echo Form::open(['method'=>'POST', 'action'=>'CommentRepliesController@createReply']); ?>

                    <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                    <div class="form-group">
                      <?php echo Form::label('body', 'Reply'); ?>

                      <?php echo Form::textarea('body', null, ['class'=>'form-control', 'rows'=>1]); ?>

                    </div>

                    <div class="form-group">
                      <?php echo Form::submit('Reply', ['class'=>'btn btn-primary']); ?>

                    </div>
                  <?php echo Form::close(); ?>

              </div> <!-- End comment-reply col-->
          </div> <!-- End comment-reply container-->

          <?php if(count($comment->replies)>0): ?>
            <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

              <?php if($reply->is_active == 1): ?>
                <!-- Nested Comment -->
                <div id="nested-comment" class="media">
                    <a class="pull-left" href="#">
                        <img height="64" class="media-object" src="<?php echo e($reply->authorPhoto($reply->author)); ?>" alt="">
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo e($reply->author); ?>

                            <small><?php echo e($reply->created_at->diffForHumans()); ?></small>
                        </h4>
                        <?php echo e($reply->body); ?>

                    </div>
                </div> <!-- End Nested Comment -->
              <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>

      </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
    $(".toggle-reply").click(function(){
      $(".comment-reply").slideToggle('slow');

    });
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>