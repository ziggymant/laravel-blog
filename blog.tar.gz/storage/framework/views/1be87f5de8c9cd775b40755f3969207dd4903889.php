<?php $__env->startSection('New Product', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div style="height:100px;" class="container">

  </div>
    <div class="panel panel-info">
        <div class="panel-heading">
            <div class="panel-title">New Product</div>
        </div>
        <div class="panel-body" >

              <?php echo Form::open(['method'=>'POST', 'action'=>'ProductController@add', 'files'=>true]); ?>


                    <!-- Text input-->
                    <div class="form-group">
                      <?php echo Form::label('name', 'Product name', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::text('name', null, ['placeholder'=>'Product name','class'=>'form-control input-md']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('description', 'Description', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::textarea('description', null, ['placeholder'=>'Description','id'=>'texarea', 'class'=>'form-control']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('price', 'Price', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::text('price', null, ['placeholder'=>'Price','class'=>'form-control input-md']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('imageurl', 'Image', ['class'=>'col-md-3 control-label']); ?>

                        <div class="col-md-9">
                          <?php echo Form::file('imageurl', null, ['id'=>'imageurl','class'=>'form-control input-md']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-9">
                          <?php echo Form::submit('submit', ['id'=>'submit','class'=>'btn btn-primary']); ?>

                        </div>
                    </div>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>