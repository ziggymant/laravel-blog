<?php $__env->startSection('Admin shop', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div style="height:100px;" class="container">

  </div>

  <div class="panel panel-info">
      <div class="panel-heading">
          <div class="panel-title">All products</div>
      </div>
      <div class="panel-body" >

          <div class="container">

              <div class="row">
                  <div class="col-md-6">
                      <a href="<?php echo e(url("/shop/new")); ?>"><button class="btn btn-success">New Product</button></a>
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-12">
                      <table class="table table-striped">
                          <thead>
                          <td>Name</td>
                          <td>Price</td>
                          <td>File</td>
                          <td></td>
                          </thead>
                          <tbody>
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <tr>
                                  <td><?php echo e($product->name); ?></td>
                                  <td><?php echo e($product->price); ?>$</td>
                                  <td>Placehold</td>
                                  <td><a href="/shop/product/destroy/<?php echo e($product->id); ?>"><button class="btn btn-danger">Delete</button></a> </td>
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
        </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>