<?php $__env->startSection('styles'); ?>

<script src="<?php echo e(asset('/js/summernote.js')); ?>"></script>
<link href="<?php echo e(asset('css/summernote.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Edit Post</h1>

<?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::model($post,['method'=>'PATCH', 'action'=>['AdminPostsController@update', $post->id], 'files'=>true]); ?>


  <div class="form-group">
  <?php echo Form::label('title', 'Title'); ?>

  <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

  </div>
  <div class="form-group">
  <?php echo Form::label('category_id', 'Category'); ?>

  <?php echo Form::select('category_id', $categories , null, ['class'=>'form-control']); ?>

  </div>

  <div class="form-group">
  <?php echo Form::label('photo_id', 'Photo'); ?>

  <?php echo Form::file('photo_id', ['class'=>'form-control']); ?>

  </div>
  <div class="form-group">
  <?php echo Form::label('body', 'Post'); ?>

  <?php echo Form::textarea('body', null, ['class'=>'form-control', 'id'=>'summernote']); ?>

  </div>

  <div class="form-group">
<?php echo Form::submit('Edit post', ['class'=>'btn btn-primary col-sm-3']); ?>

</div>

<?php echo Form::close(); ?>


<?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminPostsController@destroy', $post->id]]); ?>


  <div class="form-group">
    <?php echo Form::submit('Delete post', ['class'=>'btn btn-danger col-sm-3']); ?>

  </div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#summernote').summernote({
              height:300,
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>