<?php $__env->startSection('content'); ?>
  <h1>Media</h1>

  <?php if(Session::has('message')): ?>
    <p class="text-success"><?php echo e(Session('message')); ?></p>
  <?php endif; ?>

  <table class="table">
  <thead>
    <tr>
      <th>Photo id</th>
      <th>Picture</th>
      <th>Path</th>
      <th>Created at</th>
      <th>Delte Image</th>
    </tr>
  </thead>
  <tbody>
  <?php if($photos): ?>
    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>
      <td><?php echo e($photo->id); ?></td>
      <td><img height="50" src="<?php echo e($photo->path); ?>" alt=""></td>
      <td><?php echo e(url($photo->path)); ?></td>
      <td><?php echo e($photo->created_at ? $photo->created_at : "No date"); ?></td>
      <td>
        <?php echo Form::open(['method'=>'Delete', 'action'=>['AdminMediaConrtoller@destroy', $photo->id]]); ?>

          <?php echo Form::submit('Delete Image', ['class'=>'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <?php endif; ?>
  </tbody>
  </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>