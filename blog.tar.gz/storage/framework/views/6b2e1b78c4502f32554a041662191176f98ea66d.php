<?php $__env->startSection('content'); ?>

  <h1>Comments</h1>

<?php if(count($comments)> 0): ?>
  <table class="table">
  <thead>
    <tr>
      <th>Comment id</th>
      <th>Post id</th>
      <th>Author</th>
      <th>Comment</th>
      <th>Created</th>
      <th>Status</th>
      <th>Delete</th>
    </tr>
  </thead>
  <tbody>

    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>
      <td><?php echo e($comment->id); ?></td>
      <td><?php echo e($comment->post_id); ?></td>
      <td><?php echo e($comment->author); ?></td>
      <td><?php echo e($comment->body); ?></td>
      <td><?php echo e($comment->created_at); ?></td>
      <td>
        <?php if($comment->is_active == 1): ?>

          <?php echo Form::open(['method'=>'PATCH', 'action'=>['PostCommentsController@update', $comment->id]]); ?>

            <input type="hidden" name="is_active" value="0">
          	<div class="form-group">
          		<?php echo Form::submit('Un-approve', ['class'=>'btn btn-danger']); ?>

          	</div>
          <?php echo Form::close(); ?>

        <?php else: ?>
          <?php echo Form::open(['method'=>'PATCH', 'action'=>['PostCommentsController@update', $comment->id]]); ?>

            <input type="hidden" name="is_active" value="1">
          	<div class="form-group">
          		<?php echo Form::submit('Approve', ['class'=>'btn btn-primary']); ?>

          	</div>
          <?php echo Form::close(); ?>

        <?php endif; ?>
      </td>
      <td>
        <?php echo Form::open(['method'=>'DELETE', 'action'=>['PostCommentsController@destroy', $comment->id]]); ?>

          <div class="form-group">
            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

          </div>
        <?php echo Form::close(); ?>


      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

  </tbody>
  </table>
  <?php else: ?>
    <h3 class="text-center">No comments</h3>
  <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>