<?php $__env->startSection('content'); ?>

  <h1 class="text-center">Oops, page not found.</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>