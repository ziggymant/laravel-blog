@extends('layouts.shop')


@section('content')

  <h1 class="text-center">Oops, page not found.</h1>

@endsection
